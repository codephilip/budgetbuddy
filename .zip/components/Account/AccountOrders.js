function AccountOrders() {
  return <>AccountOrders</>;
}

export default AccountOrders;
